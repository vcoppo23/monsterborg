#!/bin/bash
/home/pi/monsterborg/monsterJoy.py > /dev/null

